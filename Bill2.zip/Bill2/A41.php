<html>
<body>
<form action="welcome_get.php" method="get">
First Name: <input type="text" name="fname" ><br>
LAST Name: <input type="text" name="lname" ><br>
number1: <input type="text" name="ename"><br>
number2: <input type="text" name="email"><br>
<input type="submit">
</form>
</body>
</html>